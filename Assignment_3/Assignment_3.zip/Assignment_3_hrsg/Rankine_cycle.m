clc; clear;

%% INPUT PARAMETERS
P_boiler = 8000;        % Boiler pressure (kPa)
P_cond   = 10;          % Condenser pressure (kPa)
T3_input = 500;         % Turbine inlet temperature (°C) 

eta_t = 0.85;           % Turbine isentropic efficiency
eta_p = 0.80;           % Pump isentropic efficiency

cp_steam = 2.08;        % kJ/kg.K (superheated steam)

%% IDEAL RANKINE CYCLE

%State 1 (Condenser outlet)
h1_i = steamTable(P_cond,'hf');
s1_i = steamTable(P_cond,'sf');
v1_i = steamTable(P_cond,'vf');
T1_i = steamTable(P_cond,'Tsat');

%State 2 (Pump - isentropic) 
wp_i = v1_i*(P_boiler - P_cond);% pump work
h2_i = h1_i + wp_i;
s2_i = s1_i;
T2_i = T1_i + 5;

% State 3 (Boiler outlet) 
Tsat_b = steamTable(P_boiler,'Tsat');

h3_i = steamTable(P_boiler,'hg') + cp_steam*(T3_input - Tsat_b);

s3_i = steamTable(P_boiler,'sg')+ cp_steam*log((T3_input+273)/(Tsat_b+273));

T3_i = T3_input;

% State 4 (Turbine - isentropic)
hf4 = steamTable(P_cond,'hf');
hg4 = steamTable(P_cond,'hg');
sf4 = steamTable(P_cond,'sf');
sg4 = steamTable(P_cond,'sg');

x4_i = (s3_i - sf4)/(sg4 - sf4);
h4_i = hf4 + x4_i*(hg4 - hf4);
s4_i = s3_i;
T4_i = T1_i;

%Ideal Performance
wt_i = h3_i - h4_i;  % turbine work
w_net_i = wt_i - wp_i;  % net work output
q_in_i = h3_i - h2_i;  % heat input
eta_i = w_net_i/q_in_i; % thermal efficiency
bwr_i = wp_i/wt_i;  % back work ratio

fprintf('IDEAL Rankine Efficiency = %.2f %%\n',eta_i*100);
fprintf('IDEAL Back Work Ratio = %.4f\n\n',bwr_i);

%% REAL RANKINE CYCLE 

% State 2 (Pump - real)
wp_r = wp_i/eta_p;  % pump work
h2_r = h1_i + wp_r;
s2_r = s1_i;
T2_r = T1_i + 8;

% State 3 (Same T3 input)
h3_r = h3_i;
s3_r = s3_i;
T3_r = T3_i;

%State 4 (Turbine - real) 
x4s_r = (s3_r - sf4)/(sg4 - sf4);
h4s_r = hf4 + x4s_r*(hg4 - hf4);

h4_r = h3_r - eta_t*(h3_r - h4s_r);
x4_r = (h4_r - hf4)/(hg4 - hf4);
s4_r = sf4 + x4_r*(sg4 - sf4);
T4_r = T1_i;

% Real Performance
wt_r = h3_r - h4_r;  % turbine work
w_net_r = wt_r - wp_r;  % net work output
q_in_r = h3_r - h2_r;   % heat input
eta_r = w_net_r/q_in_r;  % thermal efficiency
bwr_r = wp_r/wt_r;    % real backwork ratio

fprintf('REAL Rankine Efficiency = %.2f %%\n',eta_r*100);
fprintf('REAL Back Work Ratio = %.4f\n\n',bwr_r);

%%  T–s DIAGRAM 
figure;
plot([s1_i s2_i s3_i s4_i s1_i],[T1_i T2_i T3_i T4_i T1_i],'b-o','LineWidth',2);
hold on;
plot([s1_i s2_r s3_r s4_r s1_i],[T1_i T2_r T3_r T4_r T1_i],'r--s','LineWidth',2);
xlabel('Entropy (kJ/kg·K)');
ylabel('Temperature (°C)');
title('T–s Diagram: Ideal vs Real Rankine Cycle');
legend('Ideal','Real');
grid on;

%% h–s DIAGRAM 
figure;
plot([s1_i s2_i s3_i s4_i s1_i],[h1_i h2_i h3_i h4_i h1_i],'b-o','LineWidth',2);
hold on;
plot([s1_i s2_r s3_r s4_r s1_i],[h1_i h2_r h3_r h4_r h1_i],'r--s','LineWidth',2);
xlabel('Entropy (kJ/kg·K)');
ylabel('Enthalpy (kJ/kg)');
title('h–s Diagram: Ideal vs Real Rankine Cycle');
legend('Ideal','Real');
grid on;

%% PARAMETRIC STUDY 
P_range = linspace(4000,12000,15);
eta_param = zeros(size(P_range));

for k = 1:length(P_range)
    Pb = P_range(k);

    wp = v1_i*(Pb - P_cond)/eta_p;
    h2 = h1_i + wp;

    Tsat_b = steamTable(Pb,'Tsat');

    h3 = steamTable(Pb,'hg')+ cp_steam*(T3_input - Tsat_b);

    s3 = steamTable(Pb,'sg')+ cp_steam*log((T3_input+273)/(Tsat_b+273));

    x4s = (s3 - sf4)/(sg4 - sf4);
    h4s = hf4 + x4s*(hg4 - hf4);
    h4 = h3 - eta_t*(h3 - h4s);

    wt = h3 - h4;
    eta_param(k) = (wt - wp)/(h3 - h2);
end

figure;
plot(P_range/1000,eta_param*100,'LineWidth',2);
xlabel('Boiler Pressure (MPa)');
ylabel('Thermal Efficiency (%)');
title('Effect of Boiler Pressure on Rankine Cycle Efficiency');
grid on;

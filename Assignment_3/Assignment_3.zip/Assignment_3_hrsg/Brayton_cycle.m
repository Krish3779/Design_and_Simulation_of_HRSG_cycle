clc; clear;

%% INPUT PARAMETERS 
P1 = 100;              % Inlet pressure (kPa) 
T1 = 300;              % Inlet temperature (K)
rp = 8;                % Compressor pressure ratio
T3 = 1400;             % Turbine inlet temperature (K)

eta_c = 0.85;          % Compressor efficiency
eta_t = 0.88;          % Turbine efficiency

R = 0.287;             % kJ/kg.K (air)
cp_const = 1.005;      % kJ/kg.K
gamma = 1.4;

%% IDEAL BRAYTON CYCLE (constant cp) 

% State 1 
P1_i = P1; T1_i = T1;
s1_i = 0;

% State 2 ( process 1-2:-Isentropic compression)
P2_i = rp * P1_i;
T2_i = T1_i * (rp)^((gamma-1)/gamma);
s2_i = s1_i;

% State 3 (Process 2-3:-Constant-pressure heat addition)
P3_i = P2_i;
T3_i = T3;
s3_i = s2_i + cp_const*log(T3_i/T2_i);

% State 4 (Process 3-4:-Isentropic expansion) 
P4_i = P1_i;
T4_i = T3_i * (1/rp)^((gamma-1)/gamma);
s4_i = s3_i;

% Ideal Performance
wc_i = cp_const*(T2_i - T1_i); % compressor work
wt_i = cp_const*(T3_i - T4_i);  % turbine work
w_net_i = wt_i - wc_i;       % Net work output
q_in_i = cp_const*(T3_i - T2_i); % heat input
eta_i = w_net_i/q_in_i;  % thermal efficiency
wr_i = wc_i/wt_i;  % ideal work ratio

fprintf('IDEAL Efficiency = %.2f %%\n',eta_i*100);
fprintf('IDEAL Work Ratio = %.3f\n\n',wr_i);

%%  REAL BRAYTON Cycle(constant cp) 

% Compressor
T2_r = T1*(1 + (1/eta_c)*((rp)^((gamma-1)/gamma) - 1));
P2_r = rp * P1;

% Turbine
T4s = T3*(1/rp)^((gamma-1)/gamma);
T4_r = T3*(1 - eta_t*(1 - T4s/T3));
P4_r = P1;

% Real Performance
wc_r = cp_const*(T2_r - T1); % compressor work
wt_r = cp_const*(T3 - T4_r);  % turbine work
w_net_r = wt_r - wc_r;   % net work output
q_in_r = cp_const*(T3 - T2_r); % heat input
eta_r = w_net_r/q_in_r;  % thermal efficiency
wr_r = wc_r/wt_r;  % real work ratio

fprintf('REAL Efficiency = %.2f %%\n',eta_r*100);
fprintf('REAL Work Ratio = %.3f\n\n',wr_r);

%%  VARIABLE cp MODEL 

cp = @(T) (1.003 + 1e-4*(T-300));   % kJ/kg.K (simple model)

wc_v = integral(cp,T1,T2_r); % compressor owrk
wt_v = integral(cp,T4_r,T3); % turbine work
q_in_v = integral(cp,T2_r,T3); % heat input
eta_v = (wt_v - wc_v)/q_in_v; % thermal efficiency

fprintf('VARIABLE cp Efficiency = %.2f %%\n\n',eta_v*100);

%% T–s DIAGRAM 
s = [0 0 s3_i s3_i 0];
T = [T1_i T2_i T3_i T4_i T1_i];

figure;
plot(s,T,'-o','LineWidth',2);
xlabel('Entropy (kJ/kg·K)');
ylabel('Temperature (K)');
title('T–s Diagram of Ideal Brayton cycle');
grid on;

%%  P–v DIAGRAM 
v1 = R*T1_i/P1_i;
v2 = R*T2_i/P2_i;
v3 = R*T3_i/P3_i;
v4 = R*T4_i/P4_i;

figure;
plot([v1 v2 v3 v4 v1],[P1_i P2_i P3_i P4_i P1_i],'-s','LineWidth',2);
xlabel('Specific Volume (m^3/kg)');
ylabel('Pressure (kPa)');
title('P–v Diagram of Ideal Brayton cycle');
grid on;

%% PRESSURE RATIO SWEEP 
rp_range = linspace(2,16,25);
w_net_vec = zeros(size(rp_range));
eta_vec = zeros(size(rp_range));

for k = 1:length(rp_range)
    rp_k = rp_range(k);

    T2 = T1*(rp_k)^((gamma-1)/gamma);
    T4 = T3*(1/rp_k)^((gamma-1)/gamma);

    wc = cp_const*(T2 - T1);
    wt = cp_const*(T3 - T4);

    w_net_vec(k) = wt - wc;
    eta_vec(k) = (wt - wc)/(cp_const*(T3 - T2));
end

figure;
plot(rp_range,w_net_vec,'LineWidth',2);
xlabel('Pressure Ratio');
ylabel('Net Work (kJ/kg)');
title('Net Work v/s Pressure Ratio in Brayton cycle ');
grid on;

figure;
plot(rp_range,eta_vec*100,'LineWidth',2);
xlabel('Pressure Ratio');
ylabel('Thermal Efficiency (%)');
title('Efficiency vs Pressure Ratio in Brayton cycle');
grid on;

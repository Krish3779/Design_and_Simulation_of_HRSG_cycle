function prop = steamTable(P, propName)
% P in kPa
% Returns saturated properties using linear interpolation

%Saturation table (excerpt, standard data)
P_sat = [10 50 100 500 1000 5000 10000];     % kPa
Tsat  = [45.8 81.3 99.6 152 180 264 311];   % °C

h_f = [191 340 419 640 762 1213 1408];      % kJ/kg
h_g = [2584 2645 2676 2748 2778 2796 2778]; % kJ/kg

s_f = [0.65 1.09 1.31 1.85 2.14 2.92 3.40]; % kJ/kgK
s_g = [8.15 7.35 7.36 6.55 6.35 5.88 5.65];

v_f = [0.001 0.001 0.001 0.0011 0.0011 0.0012 0.0013]; % m³/kg

%Interpolation
switch propName
    case 'Tsat'
        prop = interp1(P_sat, Tsat, P);
    case 'hf'
        prop = interp1(P_sat, h_f, P);
    case 'hg'
        prop = interp1(P_sat, h_g, P);
    case 'sf'
        prop = interp1(P_sat, s_f, P);
    case 'sg'
        prop = interp1(P_sat, s_g, P);
    case 'vf'
        prop = interp1(P_sat, v_f, P);
    otherwise
        error('Invalid property name');
end
end

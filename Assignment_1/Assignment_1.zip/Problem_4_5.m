%Problem 4
T1 = 310;
T2 = 670;
Tb = 300;

% Enthalpy and entropy functions
h  = @(T) 300 + 2.5*T + 0.0007*T.^2;     
s  = @(T) 2.0*log(T) + 0.001*T;         

% Property differences
dh = h(T2) - h(T1);   
ds = s(T2) - s(T1);  

% Heat transfer range (kW)
Q = linspace(20,100,300);

% Mass flow rate range (kg/s)
m = linspace(0.01,20,400);

% Create grid of Q and m
[Qm, mm] = meshgrid(Q, m);

% Entropy generation rate
Sgen = mm.*ds - Qm./Tb;

% Feasible region (Second Law)
feasible = Sgen >= 0;

% Plot feasible operating region
figure
contourf(Qm, mm, feasible, 1)
xlabel('Heat Transfer Rate(kW)')
ylabel('Mass Flow Rate (kg/s)')
title('Feasible Operating Region')
colorbar


%problem 5:-

T3 = 350;       
T4 = 900;        
T0 = 298;        

% Heat capacity function (J/kg·K)
cp = @(T) 1200 + 0.4*T - 1.2e-4*T.^2;

% Entropy change (numerical integration)
ds_1 = integral(@(T) cp(T)./T, T3, T4);

% Irreversibility levels
irr = [0.02 0.10];   % 2% and 10%

% Exergy destruction
Xdest = T0 * ds_1 .* irr;

% Plot
figure
plot(irr*100, Xdest, '-o')
xlabel('Irreversibility Level (%)')
ylabel('Exergy Destruction (J/kg)')
title('Exergy Destruction vs Irreversibility')
grid on
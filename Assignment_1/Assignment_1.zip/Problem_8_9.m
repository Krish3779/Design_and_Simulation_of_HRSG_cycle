%Problem 8:-

Tb = 300;            
c  = 2.5;            % kJ/K
Qtot = 5e5;          % total heat input (kJ)
tf = 2000;           % total time (s)

% Discretization
N = 50;              
dt = tf/N;

% Initial guess: uniform heating
q0 = ones(N,1)*(Qtot/tf);

% Objective function: total entropy generation
obj = @(q) entropy_gen(q, c, Tb, dt);

%Equality constraint: total heat fixed
Aeq = ones(1,N)*dt;
beq = Qtot;

% Bounds (heat input must be positive)
lb = zeros(N,1);
ub = [];

% Optimization
q_opt = fmincon(obj, q0, [], [], Aeq, beq, lb, ub);

%Uniform heating profile
q_uni = q0;

% Plot comparison
t = linspace(0, tf, N);
figure
plot(t, q_opt, 'b', t, q_uni, 'r--')
xlabel('Time (s)')
ylabel('Heat Input q(t) (kJ/s)')
legend('Optimal Heating','Uniform Heating')
title('Optimal vs Uniform Heating Profile')
grid on

% Local function
function S = entropy_gen(q, c, Tb, dt)
    T = zeros(length(q),1);
    T(1) = 300;   % initial temperature

    % Temperature evolution
    for i = 2:length(q)
        T(i) = T(i-1) + q(i-1)*dt/c;
    end

    % Entropy generation
    S = sum( q.*(1./T - 1/Tb) * dt );
end



%Problem 9:-

Rg = 8.314e-3;     % kJ/(mol·K)
cap = 1.8;         % kJ/K
A_true = 1e5;      % true A
E_true = 45;       % true E (kJ/mol)

% Time span
time = linspace(0,5000,100);

% Initial temperature
Tstart = 300;

% Generate synthetic data 
param_true = [A_true E_true];

% Solve ODE to get true temperature
[~, Tclean] = ode45(@(t,T) temp_ode(t,T,param_true,Rg,cap), time, Tstart);

% Add 1% noise
Tdata = Tclean .* (1 + 0.01*randn(size(Tclean)));

%Parameter estimation 
% Initial guess
param_guess = [5e4 30];

% Curve fitting
param_est = lsqcurvefit(@(p,t) model_temp(p,t,Tstart,Rg,cap),param_guess, time, Tdata);

A_est = param_est(1);
E_est = param_est(2);

% Display results
fprintf('Estimated A = %.2e\n', A_est)
fprintf('Estimated E = %.2f kJ/mol\n', E_est)

% Plot
figure
plot(time, Tdata, 'o', time, model_temp(param_est,time,Tstart,Rg,cap), '-')
xlabel('Time (s)')
ylabel('Temperature (K)')
legend('Noisy Data','Model Fit')
title('Parameter Estimation from Synthetic Data')
grid on

% Local functions 
function dTdt = temp_ode(t,T,p,Rg,cap)
    A = p(1);
    E = p(2);
    rate = A*exp(-E/(Rg*T));
    heat = 2000*exp(-0.001*t);
    dTdt = (rate + heat)/cap;
end

function Tmodel = model_temp(p,tspan,T0,Rg,cap)
    [~, Tmodel] = ode45(@(t,T) temp_ode(t,T,p,Rg,cap), tspan, T0);
end

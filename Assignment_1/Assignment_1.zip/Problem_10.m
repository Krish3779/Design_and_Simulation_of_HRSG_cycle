%Problem 10

Tc = 270;          
Th = 320;          
alpha = 0.02;
k = 50;
Sgen_max = 0.05;   

% Bounds for pressure ratio
rp_lb = 1.1;
rp_ub = 6;

% Initial guess
rp0 = 2;

% Optimization options
options = optimoptions('fmincon','Display','iter');

% Optimization
rp_opt = fmincon(@(rp) -objective(rp,Tc,Th,alpha,k),rp0, [], [], [], [],rp_lb, rp_ub,@(rp) entropy_constraint(rp,Tc,Th),options);

% Display result
fprintf('Optimal pressure ratio rp = %.2f\n', rp_opt)

%  Plots 
rp = linspace(1.1,6,200);

COP = Tc./(Th-Tc) .* (1 - alpha*(rp-1).^2) ./ rp;
Wc  = k*(sqrt(rp)-1);
Qh  = COP .* Wc;
Sgen = Qh./Th - Qh./Tc;

figure
subplot(3,1,1)
plot(rp,COP), ylabel('COP'), grid on

subplot(3,1,2)
plot(rp,Sgen), ylabel('Entropy Generation (kJ/K)'), grid on
yline(Sgen_max,'r--')

subplot(3,1,3)
plot(rp,Qh./Wc), ylabel('Q_h / W_c'), xlabel('Pressure Ratio'), grid on

%  Local functions 
function val = objective(rp,Tc,Th,alpha,k)
    COP = Tc/(Th-Tc) * (1 - alpha*(rp-1)^2)/rp;
    Wc  = k*(sqrt(rp)-1);
    Qh  = COP*Wc;
    val = Qh/Wc;   % heat delivered per unit work
end

function [c,ceq] = entropy_constraint(rp,Tc,Th)
    COP = Tc/(Th-Tc) * (1 - 0.02*(rp-1)^2)/rp;
    Wc  = 50*(sqrt(rp)-1);
    Qh  = COP*Wc;
    Sgen = Qh/Th - Qh/Tc;
    c = Sgen - 0.05;  % inequality: Sgen ≤ 0.05
    ceq = [];
end

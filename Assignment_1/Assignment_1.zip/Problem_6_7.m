%Problem 6:-

% Time grid (seconds)
t = linspace(0,5000,5000);

% Boundary temperatures (K)
Th = 900 - 300*exp(-0.0008*t);
Tc = 300 + 40*sin(0.002*t);

% Efficiency
eta = 1 - Tc./Th;

% Heat input (kW)
Qin = 20000*(1 + 0.3*sin(0.003*t));

% Power output (kW)
P = eta .* Qin;



% Work output (kJ)
W = trapz(t, P);

% Entropy generation rate (kW/K)
Sgen = Qin./Th - Qin./Tc;

% Plot efficiency and entropy generation
figure
plot(t, eta, 'b', t, Sgen, 'r')
xlabel('Time (s)')
ylabel('Value')
legend('Efficiency ', 'Entropy Generation')
title('Dynamic Efficiency and Entropy Generation')
grid on



%Problem 7:-

m = 1.25;          % polytropic index
P_a = 1e5;          % Pa
P_b = 10e5;         % Pa
T_a = 300;          % K
R  = 287;          % J/(kg·K)

% Internal energy function (kJ/kg)
u = @(T) 500 + 0.8*T + 1.5e-3*T.^2;

% For ideal gas: T2/T1 = (P2/P1)^((m-1)/m)
T_b= T_a*(P_b/P_a)^((m-1)/m);

% Change in internal energy 
du = u(T_b) - u(T_a);    % kJ/kg

% Work calculation (numerical)
% PV^m = C  →  P = C/V^m
V_a = R*T_a/P_a;
V_b = R*T_b/P_b;
C  = P_a*V_a^m;

P = @(V) C./V.^m;   % pressure as function of volume

W_num = integral(@(V) P(V), V_a, V_b)/1000;  % kJ/kg

% Analytical polytropic work
W_ana = (P_b*V_b - P_a*V_a)/(1 - m)/1000;  % kJ/kg

% Heat transfer
Q = du + W_num;

fprintf('Final Temperature TB = %.2f K\n', T_b)
fprintf('Delta u = %.2f kJ/kg\n', du)
fprintf('Numerical Work = %.2f kJ/kg\n', W_num)
fprintf('Analytical Work = %.2f kJ/kg\n', W_ana)
fprintf('Heat Transfer Q = %.2f kJ/kg\n', Q)
%Problem 1

T1=320;
T2=820;
Cv=@(T) 700 + 0.35*T - 2e-4*T.^2;  
% Symbolic integration
syms T
cv_sym = 700 + 0.35*T - 2e-4*T^2;
du_sym = int(cv_sym, T, T1, T2);

du_exact = double(du_sym);

% integral method
du_integral=integral(Cv, T1, T2);

% trapeziodal rule
N = 50;                 % initial grid size
T = linspace(T1, T2, N);
du_trapz=trapz(T, Cv(T));

% minimum grid resolution for error
N_vals = 10:10:1000;
error_percent = zeros(size(N_vals));
for i = 1:length(N_vals)
    N = N_vals(i);
    T = linspace(320, 820, N);
    du_num = trapz(T, Cv(T));
    error_percent(i) = abs((du_num - du_exact)/du_exact)*100;
end
% Find minimum N satisfying error < 0.1%
N_min = N_vals(find(error_percent < 0.1, 1));
%comparison
fprintf('Analytical (exact)    : %.4f kJ/kg\n', du_exact/1000)
fprintf('Integral()            : %.4f kJ/kg\n', du_integral/1000)
fprintf('Trapz()         : %.4f kJ/kg\n',trapz(linspace(T1,T2,60), Cv(linspace(T1,T2,60)))/1000)


%Problem 2

%du/dt=qext(t)+r(T) where qext(t)=5000*e(-.002*t)(kJ/s) and
%r(T)=1500*(1-e(-0.01*T) (KJ/s)
%Part 1:- integrate du/dt from 0 to 4000 sec.

% Energy balance ODE
dudt = @(t,u) 5000*exp(-0.002*t) +1500*(1 - exp(-0.01 *((-1.1 + sqrt(1.1^2 - 4*0.0012*(450-u))) / (2*0.0012))));
%T(u)=(-1.1 + sqrt(1.1^2 - 4*0.0012*(450-u)) / (2*0.0012)
tspan = [0 4000];
u0 = 450;        % initial internal energy (T ≈ 0 reference)

[t,u] = ode45(dudt, tspan, u0);
%PART 2 — Convert u(t) to Temperature T(t)

u_of_T = @(T) 450 + 1.1*T + 0.0012*T.^2;

T3 = zeros(size(u));
Tguess = 300;    % initial guess

for i = 1:length(u)
    T3(i) = fsolve(@(Temp) u_of_T(Temp) - u(i), Tguess,optimoptions('fsolve','Display','off'));
    Tguess = T(i);   % good initial guess for next step
end
%PART 3 — When Does Reaction Heat Surpass External Heating?
q_ext = 5000*exp(-0.002*t);
r_T = 1500*(1 - exp(-0.01*T));
idx = find(r_T > q_ext, 1);
t_cross = t(idx);

% Problem 3
% P1=1 bar ;P2=20 bar; n=1.28;
% part 1:- Determine T(P)
% T(P)=T1(P/P1)^(n-1/n);

P_start = 1;          % bar
P_end = 20;           % bar
poly_n = 1.28;
T_start = 300;        % K

cp_val = 1.05;        % kJ/kg-K
R_val = 0.287;        % kJ/kg-K

P_vec = linspace(P_start, P_end, 500);

T_vec = T_start * (P_vec/P_start).^((poly_n-1)/poly_n);
% part 2:-Numerical Evaluation of Real-Gas Entropy Change
Z_vec = 1 + 0.0008*P_vec - 120 ./ T_vec;
dT_dP = gradient(T_vec, P_vec);
integrand_real = cp_val * (dT_dP ./ T_vec) - R_val * (Z_vec ./ P_vec);
ds_real = trapz(P_vec, integrand_real);

%PART 3 — Ideal-Gas Entropy Change

integrand_ideal = cp_val *(dT_dP./T_vec) - R_val./P_vec;
ds_ideal=trapz(P_vec,integrand_ideal);

%PART 4 — Percent Deviation
percent_dev = abs((ds_real - ds_ideal)/ds_ideal) * 100;

fprintf('Real-gas entropy change = %.4f kJ/(kg·K)\n', ds_real)
fprintf('Ideal-gas entropy change = %.4f kJ/(kg·K)\n', ds_ideal)
fprintf('Percent deviation = %.2f %%\n', percent_dev)